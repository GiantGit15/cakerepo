$(function() {
    
    //----This is for preparing Tabs
    
    $( "#screens" ).tabs();
    
    $("#field2-type2").buttonset();
    
    $("#type-date").datepicker();
    //
    $("#screen1-next").click(function() {
        runEffect();
    });
    
    function runEffect() {
        $( "#screen1" ).animate({
            width: 500,
        }, 100, hide_first_screen );
    };
     
    // callback function to showing the Tabs
    function hide_first_screen() {
        $("#screen1").css("display", "none");
        show_tabs();
    };
    function show_tabs() {
        $("#screens").show("slide", { }, 700);
    }
    
    $("#screen4-save").click(function() {    
        saveData();
    });
    function saveData() {
        var save_data = $("body").html();
        $.ajax({
            type: 'post',
            url: save_url,
            data: {save_data: save_data},
            success: function(response) {
                alert(response);
            },
            error: function(e) {
                alert("An error occurred: " + e.responseText.message);
            }
        });
    }
    $(".btn-upload").click(function() {
        $("#avatar-modal").modal('show');
    });
});