<?php
namespace App\Model\Table;

use Cake\ORM\Table;

class FormTable extends Table
{
    public function initialize(array $config)
    {
        
    }
}